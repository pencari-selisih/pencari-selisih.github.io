window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.matcha = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const amountInBig = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const chainId = String(chainInfo.Kode_Chain);
      const userAddr = wallet || '0x3B6f633a7BB105b7D04592bBBA2F75Db6D95A210';

      const params = new URLSearchParams({
        chainId: chainId,
        buyToken: tokenOut,
        sellToken: tokenIn,
        sellAmount: amountInBig,
        taker: userAddr,
        slippageBps: String(Math.round(parseFloat(slippage) * 100))
      });

      const url = `https://0x.xnfts.dev/swap/allowance-holder/quote?${params.toString()}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          '0x-version': 'v2'
        }
      });

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errText}`);
      }

      const data = await response.json();
      if (!data?.buyAmount) throw new Error("Matcha: No buyAmount in response");

      const amountOut = parseFloat(data.buyAmount) / Math.pow(10, decOut);
      
      // Extract fee in USD if available
      let feeUsd = 0;
      if (data.fees?.gasFee?.amountUSD) {
        feeUsd = parseFloat(data.fees.gasFee.amountUSD);
      } else if (data.gasCostUsd) {
        feeUsd = parseFloat(data.gasCostUsd);
      }

      return { 
        price: amountOut, 
        feeUsd, 
        routeTool: 'MATCHA' 
      };
    } catch (e) {
      console.log('MATCHA Fetch Error:', e);
      return { 
        price: 0, 
        feeUsd: 0, 
        routeTool: 'MATCHA_ERR', 
        isError: true, 
        errorMsg: e.message || 'Request failed' 
      };
    }
  }
};
