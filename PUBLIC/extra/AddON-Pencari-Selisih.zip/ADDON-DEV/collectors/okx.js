window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.okx = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1, symIn = '', symOut = '') {
    // Detect direction (DTC: Stable -> Coin)
    const STABLES = ['0x67b725d7e342d7b611fa85e859df9697d9378b2e', '0x55d398326f99059ff775485246999027b3197955', '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d', '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c'];
    
    try {
      const chainIdNum = parseInt(chainInfo.Kode_Chain);
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';
      
      const NATIVE_TOKEN = '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee';

      const token0 = { chainId: chainIdNum, symbol: symIn, decimals: decIn };
      if (tokenIn.toLowerCase() !== NATIVE_TOKEN) token0.address = tokenIn;

      const token1 = { chainId: chainIdNum, symbol: symOut, decimals: decOut };
      if (tokenOut.toLowerCase() !== NATIVE_TOKEN) token1.address = tokenOut;

      const body = {
        isAuto: true,
        amount: amountIn, 
        token0,
        token1,
        backer: ['OKX'],
        wallet: userAddr,
        slippage: slippage.toString()
      };

      const response = await fetch('https://superlink-server.coin98.tech/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8' },
        body: JSON.stringify(body)
      });

      const data = await response.json();
      if (!data?.data?.[0]) throw new Error("C98-OKX: No quote data");

      const amountOut = parseFloat(data.data[0].amount);
      const feeUsd = parseFloat(data.data[0].gasUsd || 0) || 0;
      return { price: amountOut, feeUsd, routeTool: 'OKX (Coin98)' };
    } catch (e) {
      console.log('OKX Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'OKX_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
