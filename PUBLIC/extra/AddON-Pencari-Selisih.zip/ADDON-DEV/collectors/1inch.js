window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors['1inch'] = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const amountInBig = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';
      const nativeAddresses = ['0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', '0x0000000000000000000000000000000000000000'];

      const srcToken = nativeAddresses.includes(tokenIn.toLowerCase()) ? '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee' : tokenIn.toLowerCase();
      const dstToken = nativeAddresses.includes(tokenOut.toLowerCase()) ? '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee' : tokenOut.toLowerCase();

      const chainId = chainInfo.Kode_Chain || 1;
      const params = new URLSearchParams({
        src: srcToken,
        dst: dstToken,
        amount: amountInBig,
        from: userAddr,
        receiver: userAddr,
        slippage: slippage.toString(),
        fee: '0.875',
        referrer: '0x365d358dc96ae70c35a1e338a9a7645313d1231b',
        disableEstimate: 'true'
      });

      const url = `https://partners.mewapi.io/oneinch/v6.0/${chainId}/swap?${params.toString()}`;

      const response = await fetch(url, {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
      });

      const data = await response.json();
      if (!data || !data.dstAmount) {
        throw new Error('ENKRYPT-1INCH: Invalid response, missing dstAmount');
      }

      const amountOut = parseFloat(data.dstAmount) / Math.pow(10, decOut);
      const feeUsd = parseFloat(data.gasUsd || data.tx?.gasUsd || data.expectedGasUsd || 0) || 0;
      return { price: amountOut, feeUsd, routeTool: '1INCH via ENKRYPT' };
    } catch (e) {
      console.log('1INCH Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: '1INCH_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
