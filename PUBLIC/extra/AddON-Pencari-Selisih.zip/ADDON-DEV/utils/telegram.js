const Telegram = {
  async sendMessage(text, personalChatId = null) {
    if (!APP_CONFIG.telegramBotToken) {
      console.warn('Telegram bot token not configured');
      return;
    }

    const url = `https://api.telegram.org/bot${APP_CONFIG.telegramBotToken}/sendMessage`;

    const send = async (chatId) => {
      try {
        await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: text,
            parse_mode: 'HTML',
            disable_web_page_preview: true
          })
        });
      } catch (e) {
        console.error(`Failed to send telegram to ${chatId}:`, e);
      }
    };

    const targets = [];
    if (APP_CONFIG.telegramGroupId) targets.push(APP_CONFIG.telegramGroupId);
    if (personalChatId && String(personalChatId).trim() && personalChatId !== APP_CONFIG.telegramGroupId) {
      targets.push(personalChatId);
    }

    if (targets.length === 0) return;
    await Promise.all(targets.map(send));
  }
};
