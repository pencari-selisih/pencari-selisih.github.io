/* Gas Monitor - Offscreen Worker
 * Menerima settings dari background.js (tidak baca storage sendiri).
 * Fetch gas prices, kirim hasil ke background untuk disimpan & diteruskan ke popup.
 */

const CHAINS = [
  { key: 'ethereum', chainId: 1,     llama: 'ethereum', priceSymbol: 'ETHUSDT', swapGas: 356190, transferGas: 65000 },
  { key: 'bsc',      chainId: 56,    llama: 'bsc',      priceSymbol: 'BNBUSDT', swapGas: 250000, transferGas: 65000, fixedGwei: 0.1 },
  { key: 'polygon',  chainId: 137,   llama: 'polygon',  priceSymbol: 'POLUSDT', priceFallback: 'MATICUSDT', swapGas: 250000, transferGas: 65000 },
  { key: 'arbitrum', chainId: 42161, llama: 'arbitrum', priceSymbol: 'ETHUSDT', swapGas: 250000, transferGas: 65000 },
  { key: 'base',     chainId: 8453,  llama: 'base',     priceSymbol: 'ETHUSDT', swapGas: 250000, transferGas: 65000 },
  { key: 'avax',     chainId: 43114, llama: 'avax',     priceSymbol: 'AVAXUSDT', swapGas: 250000, transferGas: 65000 },
];

const CHAINS_SOLANA = [
  { key: 'solana',   rpc: 'https://solana-mainnet.wallet.brave.com', priceSymbol: 'SOLUSDT', swapComputeUnits: 200000, transferLamports: 5000 },
];

const EVM_CHAIN_KEYS = new Set(CHAINS.map(c => c.key));
const SOLANA_CHAIN_KEYS = new Set(CHAINS_SOLANA.map(c => c.key));
const CHAIN_ALIASES = { avalanche: 'avax' };

const REQUEST_TIMEOUT = 8000;
const bnUrl    = (id)    => `https://api.blocknative.com/gasprices/blockprices?chainid=${id}`;
const llamaUrl = (chain) => `https://rpc.llama-rpc.com/${CHAIN_ALIASES[chain] || chain}?source=llamaswap`;
const binanceUrl = (syms) => `https://api.binance.com/api/v3/ticker/price?symbols=${encodeURIComponent(JSON.stringify(syms))}`;

// Default settings — di-override oleh pesan dari background
let settings = {
  refreshSec: 30,
  bnEnabled: true,
  llEnabled: true,
  enabledChainsBn:  CHAINS.map(c => c.key),
  enabledChainsRpc: CHAINS.map(c => c.key),
  enabledChainsSol: CHAINS_SOLANA.map(c => c.key)
};
let timer = null;
let priceCache = { data: null, ts: 0 };

function normalizeChainList(list, allowedKeys) {
  if (!Array.isArray(list)) return [];
  return [...new Set(list.map(key => CHAIN_ALIASES[key] || key).filter(key => allowedKeys.has(key)))];
}

function applySettings(nextSettings = {}) {
  settings = { ...settings, ...nextSettings };

  const legacyChains = normalizeChainList(settings.enabledChains || [], EVM_CHAIN_KEYS);
  settings.enabledChainsBn = normalizeChainList(settings.enabledChainsBn || legacyChains, EVM_CHAIN_KEYS);
  settings.enabledChainsRpc = normalizeChainList(settings.enabledChainsRpc || legacyChains, EVM_CHAIN_KEYS);
  settings.enabledChainsSol = normalizeChainList(settings.enabledChainsSol || [], SOLANA_CHAIN_KEYS);

  if (!settings.enabledChainsSol.length && Array.isArray(nextSettings.enabledChains) && nextSettings.enabledChains.includes('solana')) {
    settings.enabledChainsSol = ['solana'];
  }
  delete settings.enabledChains;
}

// ── Message Listener ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

  if (msg.type === 'START_AUTO') {
    if (msg.settings) {
      applySettings(msg.settings);
    }
    stopTimer();
    fetchAndSave();
    timer = setInterval(fetchAndSave, (settings.refreshSec || 30) * 1000);
    sendResponse({ ok: true });
  }

  else if (msg.type === 'STOP_AUTO') {
    stopTimer();
    sendResponse({ ok: true });
  }

  else if (msg.type === 'FETCH_ONCE') {
    if (msg.settings) {
      applySettings(msg.settings);
    }
    fetchAndSave();
    sendResponse({ ok: true });
  }

  else if (msg.type === 'APPLY_SETTINGS') {
    if (msg.settings) {
      applySettings(msg.settings);
    }
    stopTimer();
    fetchAndSave();
    timer = setInterval(fetchAndSave, (settings.refreshSec || 30) * 1000);
    sendResponse({ ok: true });
  }
});

function stopTimer() {
  if (timer) { clearInterval(timer); timer = null; }
}

// ── Fetch Helpers ────────────────────────────────────────────────
async function getJSON(url, opts = {}) {
  const sig = AbortSignal.timeout(REQUEST_TIMEOUT);
  const res = await fetch(url, { ...opts, signal: sig });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fetchPrices() {
  const now = Date.now();
  if (priceCache.data && (now - priceCache.ts) < 10000) return priceCache.data;
  
  // Ambil gabungan (union) dari chain yang aktif di BN maupun RPC
  const bnSet  = normalizeChainList(settings.enabledChainsBn, EVM_CHAIN_KEYS);
  const rpcSet = normalizeChainList(settings.enabledChainsRpc, EVM_CHAIN_KEYS);
  const solSet = normalizeChainList(settings.enabledChainsSol, SOLANA_CHAIN_KEYS);
  const union  = [...new Set([...bnSet, ...rpcSet])];
  
  const active = [
    ...CHAINS.filter(c => union.includes(c.key)),
    ...CHAINS_SOLANA.filter(c => solSet.includes(c.key)),
  ];
  const syms = [...new Set(active.flatMap(c => [c.priceSymbol, c.priceFallback].filter(Boolean)))];
  if (syms.length === 0) return priceCache.data || {};

  try {
    const data = await getJSON(binanceUrl(syms));
    const map = {};
    (data || []).forEach(r => { if (r?.symbol && r?.price) map[r.symbol] = Number(r.price); });
    priceCache = { data: map, ts: now };
    return map;
  } catch { return priceCache.data || {}; }
}

async function fetchBlocknative(chain) {
  if (chain.fixedGwei != null) return { gasGwei: chain.fixedGwei };
  const res = await getJSON(bnUrl(chain.chainId));
  const bp  = res?.blockPrices?.[0] || {};
  const est = (bp.estimatedPrices || []).find(p => p.confidence === 70) || (bp.estimatedPrices || [])[0] || {};
  const raw = est?.price ?? est?.maxFeePerGas ?? null;
  const g = Number(raw);
  return { gasGwei: Number.isFinite(g) ? g : null };
}

async function fetchLlama(chain) {
  if (chain.fixedGwei != null) return { gasGwei: chain.fixedGwei };
  const payload = { jsonrpc: '2.0', id: 1, method: 'eth_gasPrice', params: [] };
  const opts = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  };
  const res = await getJSON(llamaUrl(chain.llama), opts).catch(async (err) => {
    if (!chain.rpcFallback) throw err;
    return getJSON(chain.rpcFallback, opts);
  });
  if (!res?.result && chain.rpcFallback) {
    const fallback = await getJSON(chain.rpcFallback, opts);
    const fallbackHex = fallback?.result;
    return { gasGwei: fallbackHex ? Number(BigInt(fallbackHex)) / 1e9 : null };
  }
  const hex = res?.result;
  return { gasGwei: hex ? Number(BigInt(hex)) / 1e9 : null };
}

async function fetchSolanaRpc(chain) {
  const res = await getJSON(chain.rpc, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'getRecentPrioritizationFees', params: [] })
  });
  const fees = res?.result || [];
  // Solana returns priority fee in micro-lamports per compute unit.
  if (fees.length === 0) return { gasGwei: null };
  const sorted = fees.map(f => f.prioritizationFee || 0).sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  return { gasGwei: median / 1e6, priorityFeeMicroLamports: median };
}

function computeCosts(gasGwei, chain, priceUsd) {
  if (gasGwei == null || priceUsd == null) return { swapUsd: null, transferUsd: null };
  const gp = gasGwei * 1e-9;
  return { swapUsd: gp * chain.swapGas * priceUsd, transferUsd: gp * chain.transferGas * priceUsd };
}

function computeSolanaCosts(priorityFeeMicroLamports, chain, priceUsd) {
  if (priorityFeeMicroLamports == null || priceUsd == null) return { swapUsd: null, transferUsd: null };
  const baseLamports = chain.transferLamports || 5000;
  const swapPriorityLamports = ((chain.swapComputeUnits || 0) * priorityFeeMicroLamports) / 1e6;
  const lamportsToUsd = lamports => (lamports / 1e9) * priceUsd;
  return {
    swapUsd: lamportsToUsd(baseLamports + swapPriorityLamports),
    transferUsd: lamportsToUsd(baseLamports)
  };
}

// ── Main Fetch ───────────────────────────────────────────────────
async function fetchAndSave() {
  const bnSet  = normalizeChainList(settings.enabledChainsBn, EVM_CHAIN_KEYS);
  const rpcSet = normalizeChainList(settings.enabledChainsRpc, EVM_CHAIN_KEYS);
  const solSet = normalizeChainList(settings.enabledChainsSol, SOLANA_CHAIN_KEYS);
  const union  = [...new Set([...bnSet, ...rpcSet])];
  
  const active = CHAINS.filter(c => union.includes(c.key));
  const activeSol = CHAINS_SOLANA.filter(c => solSet.includes(c.key));
  if (active.length === 0 && activeSol.length === 0) return;

  const result = { bn: {}, rpc: {}, solana: {}, timestamp: Date.now() };

  try {
    const prices = await fetchPrices();

    // Fetch EVM chains (Blocknative & DefiLlama)
    const tasks = active.flatMap(chain => {
      const pu = prices[chain.priceSymbol] ?? prices[chain.priceFallback] ?? null;
      const out = [];

      // Fetch BN jika source ON dan chain ini aktif di BN
      if (settings.bnEnabled !== false && bnSet.includes(chain.key)) {
        out.push(
          fetchBlocknative(chain)
            .then(({ gasGwei }) => { result.bn[chain.key] = { gasGwei, ...computeCosts(gasGwei, chain, pu) }; })
            .catch(() => { result.bn[chain.key] = { gasGwei: null, swapUsd: null, transferUsd: null }; })
        );
      }

      // Fetch RPC jika source ON dan chain ini aktif di RPC
      if (settings.llEnabled !== false && rpcSet.includes(chain.key)) {
        out.push(
          fetchLlama(chain)
            .then(({ gasGwei }) => { result.rpc[chain.key] = { gasGwei, ...computeCosts(gasGwei, chain, pu) }; })
            .catch(() => { result.rpc[chain.key] = { gasGwei: null, swapUsd: null, transferUsd: null }; })
        );
      }

      return out;
    });

    // Fetch Solana (separate RPC - always enabled)
    const solTasks = activeSol.flatMap(chain => {
      const pu = prices[chain.priceSymbol] ?? null;
      const out = [];

      out.push(
        fetchSolanaRpc(chain)
          .then(({ gasGwei, priorityFeeMicroLamports }) => {
            result.solana[chain.key] = { gasGwei, ...computeSolanaCosts(priorityFeeMicroLamports, chain, pu) };
          })
          .catch(() => { result.solana[chain.key] = { gasGwei: null, swapUsd: null, transferUsd: null }; })
      );

      return out;
    });

    await Promise.allSettled([...tasks, ...solTasks]);
  } catch (_) {}

  // Kirim ke background untuk disimpan ke storage & diteruskan ke popup
  chrome.runtime.sendMessage({ type: 'SAVE_GAS_DATA', data: result }).catch(() => {});
}
