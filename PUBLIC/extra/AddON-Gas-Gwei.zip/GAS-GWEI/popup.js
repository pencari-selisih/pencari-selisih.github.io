/* global chrome */
(function () {
  'use strict';

  const chains = [
    { key: 'ethereum', fullName: 'Ethereum', nameClass: 'chain-name-eth', logo: 'img/ethereum.png', gasLink: 'https://etherscan.io/gastracker' },
    { key: 'bsc',      fullName: 'BNB Chain', nameClass: 'chain-name-bsc', logo: 'img/bsc.png',      gasLink: 'https://bscscan.com/gastracker' },
    { key: 'polygon',  fullName: 'Polygon',   nameClass: 'chain-name-pol', logo: 'img/polygon.png',  gasLink: 'https://polygonscan.com/gastracker' },
    { key: 'arbitrum', fullName: 'Arbitrum',  nameClass: 'chain-name-arb', logo: 'img/arbitrum.png', gasLink: 'https://arbiscan.io/gastracker' },
    { key: 'base',     fullName: 'Base',      nameClass: 'chain-name-base',logo: 'img/base.png',     gasLink: 'https://basescan.org/gastracker' },
    { key: 'avax',     fullName: 'Avalanche', nameClass: 'chain-name-avax',logo: 'img/avalanche.png',gasLink: 'https://snowtrace.io/gastracker' },
  ];

  const chainsSolana = [
    { key: 'solana',   fullName: 'Solana',    nameClass: 'chain-name-sol', logo: 'img/solana.png',   gasLink: 'https://solscan.io' },
  ];

  const evmChainKeys = new Set(chains.map(c => c.key));
  const solanaChainKeys = new Set(chainsSolana.map(c => c.key));
  const chainAliases = { avalanche: 'avax' };

  /* ─── State ─────────────────────────────────────────────── */
  let isAuto           = false;
  let enabledChainsBn  = new Set(chains.map(c => c.key));
  let enabledChainsRpc = new Set(chains.map(c => c.key));
  let enabledChainsSol = new Set(chainsSolana.map(c => c.key));

  const qs  = sel => document.querySelector(sel);
  const qsa = sel => document.querySelectorAll(sel);

  function normalizeChainList(list, allowedKeys) {
    if (!Array.isArray(list)) return [];
    return [...new Set(list.map(key => chainAliases[key] || key).filter(key => allowedKeys.has(key)))];
  }

  function isBnEnabled() { return qs('#toggleBn').checked; }
  function isLlEnabled() { return qs('#toggleLl').checked; }
  function fmtGwei(n) { return (n == null || !Number.isFinite(n)) ? '—' : n.toFixed(2); }
  function fmtUsd(n)  { return (n == null || !Number.isFinite(n)) ? '—' : `$${n.toFixed(4)}`; }
  function getRefreshSec() { return Math.max(10, Number(qs('#refreshSec').value || 30)); }

  qs('#refreshSec').addEventListener('change', saveConfig);

  // CSP fix: stopPropagation pada label toggle di tab agar klik label tidak trigger tab switch
  ['labelBn', 'labelLl'].forEach(id => {
    qs(`#${id}`)?.addEventListener('click', e => e.stopPropagation());
  });

  /* ─── Table: init rows ──────────────────────────────────── */
  function initTableRows(tbodyId) {
    const tbody = qs(tbodyId);
    if (!tbody || tbody.querySelector('tr')) return;
    let enabledSet, chainsArray;
    
    if (tbodyId === '#tbody-bn') {
      enabledSet = enabledChainsBn;
      chainsArray = chains;
    } else if (tbodyId === '#tbody-rpc') {
      enabledSet = enabledChainsRpc;
      chainsArray = chains;
    } else if (tbodyId === '#tbody-sol') {
      enabledSet = enabledChainsSol;
      chainsArray = chainsSolana;
    }
    
    tbody.innerHTML = chainsArray.map(c => {
      const on = enabledSet.has(c.key);
      return `
        <tr data-key="${c.key}" class="${on ? 'chain-on' : 'chain-off'}">
          <td>
            <div class="chain-cell">
              <label class="mini-toggle" title="${on ? 'Klik untuk nonaktifkan' : 'Klik untuk aktifkan'}">
                <input type="checkbox" class="chain-toggle-inp" data-key="${c.key}" ${on ? 'checked' : ''} />
                <span class="mini-track"></span>
              </label>
              <span class="chain-badge">
                <img class="chain-icon" src="${c.logo}" alt="${c.fullName}" />
                <a class="chain-link ${c.nameClass}" href="${c.gasLink}" target="_blank" rel="noopener">${c.fullName}</a>
              </span>
            </div>
          </td>
          <td class="td-gas"  data-cell="gas">${on ? '···' : '—'}</td>
          <td class="td-swap" data-cell="swap">${on ? '···' : '—'}</td>
          <td class="td-send" data-cell="send">${on ? '···' : '—'}</td>
        </tr>`;
    }).join('');

    tbody.querySelectorAll('.chain-toggle-inp').forEach(inp => {
      inp.addEventListener('change', e => { 
        e.stopPropagation(); 
        toggleChain(inp.dataset.key, tbodyId); 
      });
    });
  }

  function updateRow(tbodyId, key, gasGwei, swapUsd, transferUsd) {
    const row = qs(`${tbodyId} tr[data-key='${key}']`);
    if (!row) return;
    const g = row.querySelector('[data-cell=gas]');
    const s = row.querySelector('[data-cell=swap]');
    const t = row.querySelector('[data-cell=send]');
    if (g) { g.textContent = fmtGwei(gasGwei); g.classList.remove('loading'); }
    if (s) { s.textContent = fmtUsd(swapUsd);  s.classList.remove('loading'); }
    if (t) { t.textContent = fmtUsd(transferUsd); t.classList.remove('loading'); }
  }

  function setRowsLoading(tbodyId) {
    let enabledSet, chainsArray;
    
    if (tbodyId === '#tbody-bn') {
      enabledSet = enabledChainsBn;
      chainsArray = chains;
    } else if (tbodyId === '#tbody-rpc') {
      enabledSet = enabledChainsRpc;
      chainsArray = chains;
    } else if (tbodyId === '#tbody-sol') {
      enabledSet = enabledChainsSol;
      chainsArray = chainsSolana;
    }
    
    chainsArray.forEach(c => {
      if (!enabledSet.has(c.key)) return;
      const row = qs(`${tbodyId} tr[data-key="${c.key}"]`);
      if (!row) return;
      ['gas','swap','send'].forEach(cell => {
        const el = row.querySelector(`[data-cell=${cell}]`);
        if (el) { el.textContent = '···'; el.classList.add('loading'); }
      });
    });
  }

  function applyRowState(tbodyId, key, isOn) {
    const row = qs(`${tbodyId} tr[data-key='${key}']`);
    if (!row) return;
    const inp = row.querySelector('.chain-toggle-inp');
    row.classList.toggle('chain-on',  isOn);
    row.classList.toggle('chain-off', !isOn);
    if (inp) { inp.checked = isOn; }
    if (!isOn) {
      ['gas','swap','send'].forEach(cell => {
        const el = row.querySelector(`[data-cell=${cell}]`);
        if (el) { el.textContent = '—'; el.classList.remove('loading'); }
      });
    }
  }

  /* ─── Chain Toggle ──────────────────────────────────────── */
  function toggleChain(key, tbodyId) {
    const enabledSet = (tbodyId === '#tbody-bn')
      ? enabledChainsBn
      : (tbodyId === '#tbody-sol' ? enabledChainsSol : enabledChainsRpc);
    if (enabledSet.has(key)) {
      if (enabledSet.size <= 1) return; // minimal 1 chain
      enabledSet.delete(key);
      applyRowState(tbodyId, key, false);
    } else {
      enabledSet.add(key);
      applyRowState(tbodyId, key, true);
    }
    saveConfig();
  }

  /* ─── Source toggle ─────────────────────────────────────── */
  function applySourceUI() {
    const bnOn = isBnEnabled(), llOn = isLlEnabled();
    
    // Toggle active class on panels to show/hide them entirely
    const panelBn = qs('#panel-bn');
    if (panelBn) panelBn.classList.toggle('active', bnOn);
    
    const panelRpc = qs('#panel-rpc');
    if (panelRpc) panelRpc.classList.toggle('active', llOn);

    // Solana always active
    const panelSol = qs('#panel-sol');
    if (panelSol) panelSol.classList.add('active');

    // Sync premium source chip styling
    qs('#chipBn')?.classList.toggle('active', bnOn);
    qs('#chipLl')?.classList.toggle('active', llOn);

    // If a source is newly enabled and table is empty, init it
    if (bnOn) initTableRows('#tbody-bn');
    if (llOn) initTableRows('#tbody-rpc');
    initTableRows('#tbody-sol');
  }

  ['toggleBn','toggleLl'].forEach(id => {
    qs(`#${id}`).addEventListener('change', () => {
      applySourceUI();
      updateAutoButton();
      // Jika AUTO aktif tapi semua source dimatikan → stop scanning
      if (isAuto && !hasActiveSource()) {
        isAuto = false;
        chrome.runtime.sendMessage({ type: 'TOGGLE_AUTO', enable: false, settings: currentSettings() }).catch(() => {});
      }
      saveConfig();
    });
  });

  /* ─── Render data ───────────────────────────────────────── */
  function renderGasData(data) {
    if (!data) return;
    
    // Update Blocknative table
    if (isBnEnabled()) {
      initTableRows('#tbody-bn');
      const bnData = data.bn || {};
      chains.forEach(c => {
        if (enabledChainsBn.has(c.key)) {
          const v = bnData[c.key];
          updateRow('#tbody-bn', c.key, v?.gasGwei, v?.swapUsd, v?.transferUsd);
        } else {
          applyRowState('#tbody-bn', c.key, false);
        }
      });
    }

    // Update DefiLlama table
    if (isLlEnabled()) {
      initTableRows('#tbody-rpc');
      const rpcData = data.rpc || {};
      chains.forEach(c => {
        if (enabledChainsRpc.has(c.key)) {
          const v = rpcData[c.key];
          updateRow('#tbody-rpc', c.key, v?.gasGwei, v?.swapUsd, v?.transferUsd);
        } else {
          applyRowState('#tbody-rpc', c.key, false);
        }
      });
    }

    // Update Solana table (always active)
    initTableRows('#tbody-sol');
    const solData = data.solana || {};
    chainsSolana.forEach(c => {
      if (enabledChainsSol.has(c.key)) {
        const v = solData[c.key];
        updateRow('#tbody-sol', c.key, v?.gasGwei, v?.swapUsd, v?.transferUsd);
      } else {
        applyRowState('#tbody-sol', c.key, false);
      }
    });

    if (data.timestamp) {
      qs('#lastUpdated').textContent = `Updated: ${new Date(data.timestamp).toLocaleTimeString()}`;
    }
    setStatus('ok');
  }

  /* ─── Status dot ────────────────────────────────────────── */
  function setStatus(state) {
    const dot = qs('#statusDot');
    if (!dot) return;
    const map = { ok: ['#22c55e','rgba(34,197,94,.3)'], loading: ['#f59e0b','rgba(245,158,11,.3)'], error: ['#ef4444','rgba(239,68,68,.3)'] };
    const [bg, sh] = map[state] || map.ok;
    dot.style.background = bg;
    dot.style.boxShadow  = `0 0 0 2px ${sh}`;
  }

  /* ─── AUTO button ───────────────────────────────────────── */
  function hasActiveSource() { return isBnEnabled() || isLlEnabled(); }

  function updateAutoButton() {
    const btn = qs('#btnAuto');
    if (!btn) return;
    if (!hasActiveSource()) {
      btn.textContent = 'AUTO OFF';
      btn.className   = 'btn btn-auto-disabled';
      btn.title       = 'Pilih minimal 1 source (Blocknative atau DefiLlama)';
    } else if (isAuto) {
      btn.textContent = 'AUTO ON';
      btn.className   = 'btn btn-auto-on';
      btn.title       = 'Klik untuk matikan auto scan';
    } else {
      btn.textContent = 'AUTO OFF';
      btn.className   = 'btn btn-auto-off';
      btn.title       = 'Klik untuk aktifkan auto scan';
    }
  }

  function setAutoUI(enabled) {
    isAuto = enabled;
    updateAutoButton();
  }

  qs('#btnAuto').addEventListener('click', () => {
    if (!hasActiveSource()) return; // block jika tidak ada source
    const next = !isAuto;
    setAutoUI(next);
    chrome.runtime.sendMessage({ type: 'TOGGLE_AUTO', enable: next, settings: currentSettings() }).catch(() => {});
  });

  /* ─── Refresh button ────────────────────────────────────── */
  qs('#btnRefresh').addEventListener('click', () => {
    setStatus('loading');
    if (isBnEnabled()) setRowsLoading('#tbody-bn');
    if (isLlEnabled()) setRowsLoading('#tbody-rpc');
    setRowsLoading('#tbody-sol');
    chrome.runtime.sendMessage({ type: 'FETCH_ONCE', settings: currentSettings() }).catch(() => {});
  });

  /* ─── Settings ──────────────────────────────────────────── */
  function currentSettings() {
    return {
      refreshSec:       getRefreshSec(),
      bnEnabled:        isBnEnabled(),
      llEnabled:        isLlEnabled(),
      enabledChainsBn:  normalizeChainList([...enabledChainsBn], evmChainKeys),
      enabledChainsRpc: normalizeChainList([...enabledChainsRpc], evmChainKeys),
      enabledChainsSol: normalizeChainList([...enabledChainsSol], solanaChainKeys),
    };
  }

  function saveConfig() {
    const cfg = currentSettings();
    chrome.storage.local.set({ gasSettings: cfg });
    chrome.runtime.sendMessage({ type: 'SETTINGS_UPDATED' }).catch(() => {});
  }

  function loadConfig() {
    chrome.storage.local.get(['gasSettings', 'gasLastData', 'autoEnabled'], (d) => {
      const cfg = d.gasSettings || {};

      if (cfg.refreshSec !== undefined) qs('#refreshSec').value = cfg.refreshSec;
      if (cfg.bnEnabled  !== undefined) qs('#toggleBn').checked = cfg.bnEnabled;
      if (cfg.llEnabled  !== undefined) qs('#toggleLl').checked = cfg.llEnabled;
      
      if (Array.isArray(cfg.enabledChainsBn) && cfg.enabledChainsBn.length > 0) {
        enabledChainsBn = new Set(normalizeChainList(cfg.enabledChainsBn, evmChainKeys));
      }
      if (Array.isArray(cfg.enabledChainsRpc) && cfg.enabledChainsRpc.length > 0) {
        enabledChainsRpc = new Set(normalizeChainList(cfg.enabledChainsRpc, evmChainKeys));
      }
      if (Array.isArray(cfg.enabledChainsSol) && cfg.enabledChainsSol.length > 0) {
        enabledChainsSol = new Set(normalizeChainList(cfg.enabledChainsSol, solanaChainKeys));
      }
      
      // Fallback for old simple config
      if (cfg.enabledChains && !cfg.enabledChainsBn && !cfg.enabledChainsRpc) {
        enabledChainsBn = new Set(normalizeChainList(cfg.enabledChains, evmChainKeys));
        enabledChainsRpc = new Set(normalizeChainList(cfg.enabledChains, evmChainKeys));
        if (cfg.enabledChains.includes('solana')) {
          enabledChainsSol = new Set(['solana']);
        }
      }

      applySourceUI();
      setAutoUI(!!d.autoEnabled);
      updateAutoButton();

      // Init tabel panel aktif
      initTableRows('#tbody-bn');
      initTableRows('#tbody-rpc');
      initTableRows('#tbody-sol');

      // Persist normalized settings so old solana/avalanche EVM entries do not keep auto scan dirty.
      saveConfig();

      // Restore data terakhir dari background scan
      if (d.gasLastData) {
        renderGasData(d.gasLastData);
      } else {
        setStatus('loading');
        chrome.runtime.sendMessage({ type: 'FETCH_ONCE', settings: currentSettings() }).catch(() => {});
      }
    });
  }

  /* ─── Messages dari background ──────────────────────────── */
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'GAS_DATA')    renderGasData(msg.data);
    if (msg.type === 'AUTO_STATUS') setAutoUI(msg.enabled);
  });

  /* ─── Init ──────────────────────────────────────────────── */
  loadConfig();

})();
